#!/usr/bin/env python3
import numpy as np
import rclpy

from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import Twist

from .edge_runtime import EdgeRuntimeBrain


class RobotBrainNode(Node):
    def __init__(self):
        super().__init__("robot_brain_node")

        self.declare_parameter("model_path", "robot_brain_int8.ts")
        self.declare_parameter("input_dim", 32)
        self.declare_parameter("cmd_scale_linear", 0.5)
        self.declare_parameter("cmd_scale_angular", 1.0)

        model_path = self.get_parameter("model_path").get_parameter_value().string_value
        input_dim = self.get_parameter("input_dim").get_parameter_value().integer_value

        self.cmd_scale_linear = self.get_parameter("cmd_scale_linear").value
        self.cmd_scale_angular = self.get_parameter("cmd_scale_angular").value

        self.brain = EdgeRuntimeBrain(model_path=model_path, input_dim=input_dim)
        self.input_dim = int(input_dim)

        self.latest_obs = np.zeros(self.input_dim, dtype=np.float32)

        self.sensor_sub = self.create_subscription(
            Float32MultiArray,
            "/brain/sensors",
            self.sensor_callback,
            10,
        )

        self.cmd_pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.motor_pub = self.create_publisher(Float32MultiArray, "/brain/motor_command", 10)

        self.timer = self.create_timer(0.05, self.control_loop)  # 20 Hz

        self.get_logger().info("RobotBrainNode started")

    def sensor_callback(self, msg: Float32MultiArray):
        data = np.array(msg.data, dtype=np.float32)
        if data.shape[0] >= self.input_dim:
            self.latest_obs = data[:self.input_dim]
        else:
            padded = np.zeros(self.input_dim, dtype=np.float32)
            padded[: data.shape[0]] = data
            self.latest_obs = padded

    def control_loop(self):
        motor = self.brain.step(self.latest_obs)

        motor_msg = Float32MultiArray()
        motor_msg.data = motor.astype(np.float32).tolist()
        self.motor_pub.publish(motor_msg)

        twist = Twist()
        if len(motor) >= 2:
            twist.linear.x = float(motor[0] * self.cmd_scale_linear)
            twist.angular.z = float(motor[1] * self.cmd_scale_angular)
        self.cmd_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = RobotBrainNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
