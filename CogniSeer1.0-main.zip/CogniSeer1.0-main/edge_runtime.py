import torch


class EdgeRuntimeBrain:
    def __init__(self, model_path="robot_brain_int8.ts", input_dim=32):
        self.model = torch.jit.load(model_path, map_location="cpu")
        self.model.eval()
        self.input_dim = input_dim

    def step(self, obs):
        with torch.no_grad():
            x = torch.tensor(obs, dtype=torch.float32).view(1, self.input_dim)
            y = self.model(x).squeeze(0).cpu().numpy()
        return y
