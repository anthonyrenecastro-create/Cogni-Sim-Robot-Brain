import torch
from brain_torch import TorchBrainConfig, TorchEdgeRobotBrain


class QuantizableBrainWrapper(torch.nn.Module):
    """
    Quantization wrapper around the main trainable parts.
    Dynamic quantization is easiest for edge CPUs.
    """
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, obs):
        out = self.model(obs)
        return out["motor_command"]


def main():
    cfg = TorchBrainConfig(input_dim=32, hidden_dim=64, motor_dim=8)
    model = TorchEdgeRobotBrain(cfg)
    checkpoint = torch.load("robot_brain_fp32.pt", map_location="cpu")
    model_state = model.state_dict()
    compatible = {
        k: v
        for k, v in checkpoint.items()
        if k in model_state and model_state[k].shape == v.shape
    }
    model.load_state_dict(compatible, strict=False)
    model.eval()
    model.reset_state(batch_size=1, device="cpu")

    wrapped = QuantizableBrainWrapper(model)

    quantized = torch.quantization.quantize_dynamic(
        wrapped,
        {torch.nn.Linear},
        dtype=torch.qint8
    )

    example = torch.randn(1, cfg.input_dim)
    traced = torch.jit.trace(quantized, example)
    traced.save("robot_brain_int8.ts")

    print("saved robot_brain_int8.ts")


if __name__ == "__main__":
    main()
