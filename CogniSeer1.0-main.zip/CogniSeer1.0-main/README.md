# CogniSeer1.0
Prototype for an edge-computing robot brain

## Deployment Flow

```bash
python train_brain.py
python quantize_brain.py
ros2 run robot_brain_ros2 robot_brain_node
```
