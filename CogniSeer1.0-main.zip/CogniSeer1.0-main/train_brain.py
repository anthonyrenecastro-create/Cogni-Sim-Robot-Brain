import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from brain_torch import TorchBrainConfig, TorchEdgeRobotBrain


class DummyRobotDataset(Dataset):
    def __init__(self, n=2000, input_dim=32, motor_dim=8):
        self.obs = torch.randn(n, input_dim)
        self.target = torch.tanh(torch.randn(n, motor_dim))

    def __len__(self):
        return len(self.obs)

    def __getitem__(self, idx):
        return self.obs[idx], self.target[idx]


def train():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = TorchBrainConfig(input_dim=32, hidden_dim=64, motor_dim=8)
    model = TorchEdgeRobotBrain(cfg).to(device)
    model.reset_state(batch_size=32, device=device)

    ds = DummyRobotDataset(input_dim=cfg.input_dim, motor_dim=cfg.motor_dim)
    loader = DataLoader(ds, batch_size=32, shuffle=True, drop_last=True)

    opt = torch.optim.Adam(model.parameters(), lr=1e-3)

    for epoch in range(10):
        total_loss = 0.0
        model.train()

        for obs, target in loader:
            obs = obs.to(device)
            target = target.to(device)

            if model.memory_state.shape[0] != obs.shape[0]:
                model.reset_state(batch_size=obs.shape[0], device=device)
            else:
                model.detach_state()

            out = model(obs)
            pred = out["motor_command"]

            control_loss = F.mse_loss(pred, target)
            sparsity_loss = 0.01 * out["spike_rate"].mean()
            stability_loss = 0.001 * (out["phi1_mean"].abs().mean() + out["phi5_mean"].abs().mean())

            loss = control_loss + sparsity_loss + stability_loss

            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()

            total_loss += loss.item()

        print(f"epoch={epoch} loss={total_loss / len(loader):.6f}")

    # Exclude transient runtime buffers so the checkpoint is batch-size agnostic.
    transient_keys = {
        "memory_state",
        "spike_mem",
        "action_state",
        "fields.phi",
        "resonance.phi",
        "resonance.stability",
        "resonance.field_mean",
        "resonance.variance",
        "field_enhanced_snn.phi1",
        "field_enhanced_snn.phi5",
        "field_enhanced_snn.Phi",
        "field_enhanced_snn.mem_potential",
    }
    stable_state = {
        k: v for k, v in model.state_dict().items() if k not in transient_keys
    }
    torch.save(stable_state, "robot_brain_fp32.pt")
    print("saved robot_brain_fp32.pt")


if __name__ == "__main__":
    train()
